# কোডেক্সান্টা — ফিক্স করা সাইট প্যাকেজ (codexanta-fixed)

আপনার ওয়েবসাইটের সব ফাইল এখানে সাজানো আছে, সাথে Connect সেকশনের
YouTube / Facebook / TikTok / Blog / Website বাটনগুলোও ঠিক করা হয়েছে।

## কী কী ঠিক করা হয়েছে

১. **বাটনগুলো কেটে যাচ্ছিল (clipped)** — ৮টা আইকন এক লাইনে বসার চেষ্টা করছিল,
   জায়গা হচ্ছিল না। তাই কার্ডের বাইরের অংশ `body`-র `overflow-x: hidden`
   কেটে ফেলছিল — ডান পাশের বাটন (Blog, TikTok 2, Blog 2) মোবাইল ও ডেস্কটপ
   দুটোতেই কেটে যাচ্ছিল। এখন বাটনগুলো **wrap** করে নতুন লাইনে বসবে —
   কোনোটা কাটা যাবে না।

২. **YouTube 2 / TikTok 2 / Blog 2 অদৃশ্য ছিল** — এদের CSS-এ কালার
   (`--color-primary`) ছিলই না, তাই রিং/বর্ডার ছাড়া কালো আইকন অন্ধকারে
   লুকিয়ে ছিল। এখন কালার, গ্লো ও রিং — সব যোগ করা হয়েছে। ভবিষ্যতে আর কোনো
   বাটন invisible না হয় সেজন্য একটা safe fallback-ও রাখা আছে।

৩. **মোবাইলে নাম দেখাচ্ছিল না** — hover করলে নাম দেখায়, কিন্তু ফোনে hover
   হয় না। এখন মোবাইলে **সব বাটনের নাম সবসময় দেখাবে** (ছোট ফন্টে, গ্যাপ দিয়ে,
   একটার উপর আরেকটা না পড়ে)।

৪. **ডেস্কটপে hover করলে নাম কার্ডের বাইরে চলে যাচ্ছিল** — padding ঠিক করা
   হয়েছে।

## আরও যা ঠিক করা হয়েছে

- **FFX 9.5.html ভাঙা ছিল** (ফাইলে শুধু "u" লেখা) — এখন একটা সুন্দর
  "Coming Soon" পেজ। আপনার আসল ফাইল থাকলে সেটা দিয়ে এটা replace করে দিবেন।
- **files/5.5/ ফোল্ডার মিসিং ছিল** — V5.5 (Html security টুল) ডাউনলোড
  লিংকের জন্য `files/5.5/`-এ index.html, package.json, server.js রাখা হয়েছে;
  `files/Codexanta-5.0.html`-ও ঠিক জায়গায় আছে।
- **index.html, secure.html, bot-2.0.html** — তিনটাই একই ফিক্স করা কন্টেন্ট
  (যেকোনো একটা live-এ replace করলেও কাজ করবে)।

## আপলোড কীভাবে করবেন

হোস্টিংয়ের ফাইল ম্যানেজারে (বা FTP) পুরনো ফাইলগুলোর উপর **overwrite/replace**
করে নিন নতুনগুলো:

সবচেয়ে গুরুত্বপূর্ণ:
- `index.html`        ← মেইন পেজ (ফিক্স করা)
- `secure.html`       ← একই কন্টেন্ট
- `bot-2.0.html`      ← একই কন্টেন্ট
- `FFX 9.5.html`      ← নতুন placeholder পেজ

বাকি ফাইলগুলো (FFX *.html, apk.html, ffxh.html, h.html, urlapp.html,
config.js, robots.txt, sitemap.xml) আগের মতোই আছে — না দিলেও চলবে, তবে
মিসিং থাকলে এগুলো দিয়ে দিবেন:
- `files/Codexanta-5.0.html`
- `files/5.5/index.html`, `files/5.5/package.json`, `files/5.5/server.js`

গুরুত্বপূর্ণ কথা:
- `favicon.ico` আপনার লোকাল ফোল্ডারে ছিল কিন্তু আপলোড হয়নি — সার্ভারে পুরনো
  `favicon.ico` থাকলে রেখে দিন (ক্ষতি নেই)।
- আপনার আসল `FFX 9.5.html` ফাইল থাকলে, সেটা দিয়ে placeholder-টা replace
  করে দিন।

## প্রিভিউ

`index.html` খুলুন — নিচে "Connect" ক্যাটাগরিতে সব বাটন দেখতে পাবেন।
ব্রাউজার উইন্ডো ছোট করে মোবাইল ভিউতেও দেখে নিন — বাটনগুলো নতুন লাইনে
বসবে, কোনোটা কাটা যাবে না।

## HTTPS (SSL) আছেও কেন http://-তে খুলছিল? (এখন ঠিক করা আছে)

ZIP-এ `.htaccess` ফাইল যোগ করা আছে যেটা:
- সব visitor-কে সবসময় **https://**-তে redirect করে (InfinityFree-সহ যেকোনো
  Apache হোস্টিংয়ে কাজ করে)
- `www.codexanta.cyou` কেও `codexanta.cyou`-তে আনে (SEO canonical)

সাথে প্রতিটি HTML পেজে একটা ছোট JS fallback আছে — হোস্ট `.htaccess`
সাপোর্ট না করলেও codexanta.cyou http://-তে খুললে নিজে থেকেই https-তে
চলে যাবে।

⚠️ InfinityFree-তে আগে **SSL চালু করবেন** (Panel → SSL → Enable), তারপর
`.htaccess` কাজ করবে। SSL চালু না করে https force করলে সাইট খুলবে না।

## ভুল লিংক / error page → হোম পেজ

`.htaccess` + `404.html` মিলে যেকোনো ভুল ঠিকানা (404), নিষিদ্ধ পেজ (403)
বা সার্ভার সমস্যা (500) হলে visitor-কে একটা সুন্দর "Page Not Found"
পেজ দেখিয়ে **৩ সেকেন্ডে হোম পেজে redirect** করবে (চাইলে বোতামে ক্লিক
করে এক ক্লিকেই যেতে পারবেন)। SEO-র জন্যও এটাই নিরাপদ — Google কে
404 স্ট্যাটাস দেখায়, visitor হোমে চলে যায়।

## ⚠️ গুরুত্ব: আগের ZIP থাকলে (overwrite নিশ্চিত করতে)

১. File Manager-এ আগে পুরনো **`index.html`, `secure.html`, `bot-2.0.html`**
   ডিলিট করে দিন (ভয় নেই — নতুন ZIP-এ সব আছে)।
২. তারপর নতুন ZIP আপলোড করে **Extract** করুন — "Overwrite?" জিজ্ঞেস করলে **হ্যাঁ**।
৩. Extract শেষ হলে File Manager-ে `index.html` আছে কিনা দেখে নিন।
৪. ব্রাউজারে **hard refresh** করুন: কম্পিউটারে `Ctrl + Shift + R`,
   মোবাইলে ট্যাব বন্ধ করে আবার খুলুন, চাইলে Incognito/Private উইন্ডোতে খুলুন।
৫. পরীক্ষা: `https://codexanta.cyou/404.html` — "404 Page Not Found"
   পেজ দেখলে নতুন ZIP চলছে। Connect সেকশনে বাটন গুলো গ্রিড-এ সারি ধরে
   বসা থাকবে — মোবাইলে ৪-৫টা করে লাইনে, ট্যাবলেটে/ল্যাপটপে বড় লাইনে।

## Connect সেকশনের নতুন ডিজাইন

- এখন মোট **৫টা বাটন**: YouTube, Facebook, TikTok, Website, Blog
- **YouTube / TikTok** — hover করলে বা click করলে ওদের **২টা করা
  channel/link** popup আসবে (YouTube→২ চ্যানেল, TikTok→২ আইডি)
- **Blog** — click করলে ১টামাত্র ব্লগ link আসবে (codexanta.blogspot.com)।
  **Blog 2 (codexastudio.blogspot.com) সম্পূর্ণ সরিয়ে ফেলা হয়েছে** —
  বাটন, লিংক ও SEO data থেকেও বাদ গেছে
- **Facebook / Website** — click করলে ওদের একটামাত্র link বাটন popup আসবে
- ফোনে: মূল বাটনে tap করলেই popup খুলবে, বাইরে tap করলে বন্ধ হবে
- **Weather বক্স সবসময় Connect এর নিচে** ঠিকমতো দেখাবে (ডেস্কটপে সামান্য
  ছোট স্কেল দেওয়া হয়েছে যেন উপরের সেকশনের উপরে চড়ে না যায়)

## About সেকশন (নতুন)

মেইন পেজে Review এর পরে **About** ক্যাটাগরি যোগ করা হয়েছে, যেখানে
Codexanta-র পরিচয় আছে: "রেডিমেড ওয়েবসাইট সোর্স কোড, কাস্টম ওয়েবসাইট ও
ডিজিটাল সলিউশন প্রদানকারী প্রযুক্তি ব্র্যান্ড" — সাথে ফ্রি টুলস, YouTube,
ব্লগ ও লক্ষ্যের বর্ণনা। Meta description, keywords ও structured data-ও
এই পরিচয় অনুযায়ী আপডেট করা হয়েছে (Google/AI যেন এটাই বলে)।

======================================================================
🔌 ব্যাকএন্ড — একটাই নতুন লিংক, চারটা সেবা (পুরনো সব বাদ)
=======================================================
সব API এখন এক সার্ভারে: https://codexanta.onrender.com

  কোথায়                    লিংক ম্যাপ
  ─────────────────────────────────────────────────
  files/5.5 (সোর্স প্রোটেক্ট)  https://codexanta.onrender.com
                              (config.js → SECURE_URL)
  h.html / ffxh.html          .../hosting
  apk.html / FFX security     .../apk   (config.js → BACKEND_URL)
  FFX 6.0                     .../tools  (config.js → API_URL_1)

- পুরনো codexa-hosting / codexa-apk / codexa-tools.onrender.com
  লিংকগুলো সম্পূর্ণ বাদ — কোথাও নেই।
- ব্যাকএন্ড ZIP: codexanta-backend.zip (Dockerfile সহ — Render-এ
  সাধারণ Web Service, নাম "codexanta", কোনো Blueprint নয়)।
- সাইটের সব ফাইলে (config.js, h.html, ffxh.html, FFX 6.0,
  apk.html, FFX security, files/5.5) নতুন লিংক বসানো আছে —
  পুরো ZIP আবার Extract করলেই হবে।
