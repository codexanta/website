window.APP_CONFIG = { 
        BACKEND_URL: "https://codexanta.onrender.com/apk",
        API_URL_1: "https://codexanta.onrender.com/tools",
        SECURE_URL: "https://codexanta.onrender.com"
    };